import React from "react";

export default function PanelBottom(){

    return(
        <div className="panel-bottom">
            <div className="container">
                <div className="row">
                    <div className="col-md-12">
                        <span>© Copyright Iago Novais - Todos os direitos reservados</span>
                    </div>
                </div>
            </div>
        </div>
    );

};