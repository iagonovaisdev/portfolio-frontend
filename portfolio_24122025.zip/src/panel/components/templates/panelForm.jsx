export default function PanelForm(props){

    return(
        <div className="panel-form">
            {props.children}
        </div>
    );

};